import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as Compass, d as MessageCircle, i as ShieldCheck, l as PenTool, o as Rocket } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/process-BXdWK6wD.js
var import_jsx_runtime = require_jsx_runtime();
var steps = [
	{
		icon: MessageCircle,
		title: "Listen",
		copy: "We start with a real conversation. Your goals, your audience, your voice; before a single pixel."
	},
	{
		icon: Compass,
		title: "Plan",
		copy: "I turn the messy middle into a clear sitemap, content plan and visual direction you can sign off on."
	},
	{
		icon: PenTool,
		title: "Design",
		copy: "Custom typography, colour and layout; never a template. You see progress every few days, not at the end."
	},
	{
		icon: Rocket,
		title: "Build & Launch",
		copy: "Hand-crafted code, hosted on fast infrastructure, tested on real devices before we go live."
	},
	{
		icon: ShieldCheck,
		title: "Support",
		copy: "30 days of free polish after launch, plus optional care plans for updates, backups and monitoring."
	}
];
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-border/60 bg-surface/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 py-20 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.25em] text-gold",
					children: "How I work"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-3 font-display text-5xl md:text-6xl text-balance",
					children: ["A calm process. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "Confident outcomes."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-muted-foreground",
					children: "Every HAMGRA project follows the same rhythm; so you always know what comes next, what's expected of you, and when we go live."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-4xl px-6 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "relative space-y-10 border-l border-border/60 pl-8",
			children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -left-[43px] grid h-10 w-10 place-items-center rounded-full border border-border bg-background text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-sm text-gold",
						children: ["Step ", String(i + 1).padStart(2, "0")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl md:text-3xl",
						children: s.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: s.copy
					})
				]
			}, s.title))
		})
	})] });
}
//#endregion
export { Process as component };
