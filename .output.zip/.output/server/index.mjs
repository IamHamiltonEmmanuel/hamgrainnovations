globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/Hamilton_Emmanuel_Resume.pdf": {
		"type": "application/pdf",
		"etag": "\"10901-pz9+ENIHp2pA+E1GiW9DyBk5OXY\"",
		"mtime": "2026-06-27T23:39:37.122Z",
		"size": 67841,
		"path": "../public/Hamilton_Emmanuel_Resume.pdf"
	},
	"/assets/contact-Cq6C7NXa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2711-SGgAPWvHHXcZWPnEOy1W5D2uW/8\"",
		"mtime": "2026-07-20T23:06:34.740Z",
		"size": 10001,
		"path": "../public/assets/contact-Cq6C7NXa.js"
	},
	"/assets/createLucideIcon-B4jqqaQH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2542-rj8ey/pXWFvT55EMX7TrP8NthMs\"",
		"mtime": "2026-07-20T23:06:34.744Z",
		"size": 9538,
		"path": "../public/assets/createLucideIcon-B4jqqaQH.js"
	},
	"/assets/download-cv-BDHb_TJP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c11-9shzrNVA0NlEoI++iBzxjiwOyiY\"",
		"mtime": "2026-07-20T23:06:34.746Z",
		"size": 3089,
		"path": "../public/assets/download-cv-BDHb_TJP.js"
	},
	"/assets/index-BtfFmaTR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54a0a-lggrS/QKzDLa0hOFbYDIH8xIHWc\"",
		"mtime": "2026-07-20T23:06:34.740Z",
		"size": 346634,
		"path": "../public/assets/index-BtfFmaTR.js"
	},
	"/assets/portfolio-DhS9vf2L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9aa-mbfgjvRsUuhe3dP9GyjJSvQpiFU\"",
		"mtime": "2026-07-20T23:06:34.747Z",
		"size": 2474,
		"path": "../public/assets/portfolio-DhS9vf2L.js"
	},
	"/assets/process-B4rfAusg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"de1-XZIhA2hDy60EWLllFJ3zedRATcY\"",
		"mtime": "2026-07-20T23:06:34.750Z",
		"size": 3553,
		"path": "../public/assets/process-B4rfAusg.js"
	},
	"/assets/project-business-BaGjTkgC.jpg": {
		"type": "image/jpeg",
		"etag": "\"10b3e-U4Hk62qxdCe4D/n6Tl4hP5VtyhI\"",
		"mtime": "2026-07-20T23:06:34.760Z",
		"size": 68414,
		"path": "../public/assets/project-business-BaGjTkgC.jpg"
	},
	"/assets/project-church-DUsMgmOj.jpg": {
		"type": "image/jpeg",
		"etag": "\"18fbc-g+zE6mgMAW54w02T+FEU/tqFfFg\"",
		"mtime": "2026-07-20T23:06:34.762Z",
		"size": 102332,
		"path": "../public/assets/project-church-DUsMgmOj.jpg"
	},
	"/assets/project-restaurant-Cyw8Fsoj.jpg": {
		"type": "image/jpeg",
		"etag": "\"12429-z1d2YAfdjYi9dIhb/0QyZDz/V0A\"",
		"mtime": "2026-07-20T23:06:34.768Z",
		"size": 74793,
		"path": "../public/assets/project-restaurant-Cyw8Fsoj.jpg"
	},
	"/assets/project-result-portal-CQuoNeZZ.jpg": {
		"type": "image/jpeg",
		"etag": "\"8e54-TGGXeh2+lxO/3ZQAiGlSZ1z7kPs\"",
		"mtime": "2026-07-20T23:06:34.770Z",
		"size": 36436,
		"path": "../public/assets/project-result-portal-CQuoNeZZ.jpg"
	},
	"/assets/project-school-admin-CUi-48an.jpg": {
		"type": "image/jpeg",
		"etag": "\"107ad-QN26OkuN8I4VcbZPBp52Qgcm32M\"",
		"mtime": "2026-07-20T23:06:34.773Z",
		"size": 67501,
		"path": "../public/assets/project-school-admin-CUi-48an.jpg"
	},
	"/assets/project-school-site-BT0r_W2O.jpg": {
		"type": "image/jpeg",
		"etag": "\"1703d-Jk4teBp5JtTXAkDcpqfxN91J7iM\"",
		"mtime": "2026-07-20T23:06:34.776Z",
		"size": 94269,
		"path": "../public/assets/project-school-site-BT0r_W2O.jpg"
	},
	"/assets/routes-BqJqCiJY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2bf0-+5dlUyfYeM+qOp6Mggc5zLH/JaY\"",
		"mtime": "2026-07-20T23:06:34.752Z",
		"size": 11248,
		"path": "../public/assets/routes-BqJqCiJY.js"
	},
	"/assets/styles-BU0Sq_pu.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14ddd-WIaq09RFJkSTHWGuTs1RlKN8PEg\"",
		"mtime": "2026-07-20T23:06:34.778Z",
		"size": 85469,
		"path": "../public/assets/styles-BU0Sq_pu.css"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"963fb-xjCyBxY4RB+dfl4g2ph8NeLrWSY\"",
		"mtime": "2026-07-09T11:40:47.079Z",
		"size": 615419,
		"path": "../public/favicon.ico"
	},
	"/assets/logo-B8s6sMjC.png": {
		"type": "image/png",
		"etag": "\"963fb-xjCyBxY4RB+dfl4g2ph8NeLrWSY\"",
		"mtime": "2026-07-20T23:06:34.757Z",
		"size": 615419,
		"path": "../public/assets/logo-B8s6sMjC.png"
	},
	"/assets/hamilton-portrait-98d8ZQDl.png": {
		"type": "image/png",
		"etag": "\"1ae03a-O78gjdYOHdPqKqQj0HOQzMGPq6A\"",
		"mtime": "2026-07-20T23:06:34.754Z",
		"size": 1761338,
		"path": "../public/assets/hamilton-portrait-98d8ZQDl.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_HFWdgh = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_HFWdgh
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
