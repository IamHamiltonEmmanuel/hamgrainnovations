//#region node_modules/.nitro/vite/services/ssr/assets/download-cv-CKKR82QF.js
var projects = [
	{
		title: "Zion Priesthood Gospel Centre",
		category: "Church Website",
		description: "A modern, responsive church website that features a clean and intuitive user interface, making it easy to explore the church's vision, ministries, leadership, services schedules, events, sermons, and contact information.",
		image: "/assets/project-church-DUsMgmOj.jpg",
		live: "https://zpgc.netlify.app",
		year: "2026"
	},
	{
		title: "Scalable Talent Nigeria",
		category: "Recruitment & Talent Solutions Website",
		description: "The website presents a clean, professional interface that showcases recuritment services, career development programs, talent sourcing, and workforce solutions in an engaging and user-friendly manner.",
		image: "/assets/project-school-admin-CUi-48an.jpg",
		live: "https://scalabletalent.com",
		year: "2026"
	},
	{
		title: "Angelic Academy",
		category: "School Result Portal",
		description: "It enables students and parents to access examination results online while providing administrators and taechers with an efficient platform to upload, process, and manage academic records.",
		image: "/assets/project-result-portal-CQuoNeZZ.jpg",
		live: "https://angelicacademy.com.ng/school/signin.php",
		year: "2026"
	},
	{
		title: "The Burgundy Restaurant",
		category: "Restaurant Website",
		description: "It features a sophisticated, modern interface, the website showcases the restaurant's story, seasonal menus, reservations, private dining experinces, culinary philosophy, and contact information with visually rich layouts and intuitive navigation.",
		image: "/assets/project-restaurant-Cyw8Fsoj.jpg",
		live: "https://theburgundyrestaurant.com",
		year: "2026"
	},
	{
		title: "Scalable Hire Business",
		category: "Business Consulting & Talent Solutions Website",
		description: "The platform presents the company's services including outplacement support, succession planning, talent development, executive advisory, and Job Application as a Service (JAaaS) through a professional, intuitve, and engaing user experience.",
		image: "/assets/project-business-BaGjTkgC.jpg",
		live: "https://scalablehirebusiness.com",
		year: "2026"
	},
	{
		title: "Blue Tech Field Instrumentation Services Limited",
		category: "Instrumentation Serivice Website",
		description: "A Nigerian-owned company specializing in the supply, installation, maintenace, and calibration of electrical and instrumentation devices. With deep understanding of the oil and gas industry.",
		image: "/assets/project-school-site-BT0r_W2O.jpg",
		live: "https://bluetechfield.netlify.app",
		year: "2026"
	}
];
function downloadCV() {
	const link = document.createElement("a");
	link.href = "/Hamilton_Emmanuel_Resume.pdf";
	link.download = "Hamilton_Emmanuel_Resume.pdf";
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
}
//#endregion
export { projects as n, downloadCV as t };
