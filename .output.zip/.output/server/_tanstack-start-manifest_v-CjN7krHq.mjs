//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CjN7krHq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/HAMILTON EMMANUEL/OneDrive/Documents/webdevcodes/hamgrainnovations.com/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/portfolio",
			"/process"
		],
		preloads: ["/assets/index-BtfFmaTR.js", "/assets/createLucideIcon-B4jqqaQH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BtfFmaTR.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/HAMILTON EMMANUEL/OneDrive/Documents/webdevcodes/hamgrainnovations.com/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BqJqCiJY.js", "/assets/download-cv-BDHb_TJP.js"]
	},
	"/contact": {
		filePath: "C:/Users/HAMILTON EMMANUEL/OneDrive/Documents/webdevcodes/hamgrainnovations.com/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-Cq6C7NXa.js"]
	},
	"/portfolio": {
		filePath: "C:/Users/HAMILTON EMMANUEL/OneDrive/Documents/webdevcodes/hamgrainnovations.com/src/routes/portfolio.tsx",
		children: void 0,
		preloads: ["/assets/portfolio-DhS9vf2L.js", "/assets/download-cv-BDHb_TJP.js"]
	},
	"/process": {
		filePath: "C:/Users/HAMILTON EMMANUEL/OneDrive/Documents/webdevcodes/hamgrainnovations.com/src/routes/process.tsx",
		children: void 0,
		preloads: ["/assets/process-B4rfAusg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
